public class Soal10 {
    public static void main(String[] args) {


    }
}
