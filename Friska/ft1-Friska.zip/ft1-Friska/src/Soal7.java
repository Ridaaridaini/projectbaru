import java.util.Scanner;

public class Soal7 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String [] kata = input.nextLine().replace(" ","").split("");
        String koma =",", kutipSatu ="'", kutipDua = "''", anotasi = "@", garismiring = "/",
                dan = "&";
        String [] karakter = {",","'","''","@ "};





    }
}
